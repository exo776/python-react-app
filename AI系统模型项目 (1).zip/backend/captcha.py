import random
import string
from PIL import Image, ImageDraw, ImageFont, ImageFilter

def generate_captcha():
    width, height = 120, 50
    image = Image.new('RGB', (width, height), (255, 255, 255))
    draw = ImageDraw.Draw(image)
    
    # 随机字符
    chars = string.ascii_uppercase + string.digits
    code = ''.join(random.choice(chars) for _ in range(4))
    
    # 绘制干扰线
    for _ in range(8):
        x1 = random.randint(0, width)
        y1 = random.randint(0, height)
        x2 = random.randint(0, width)
        y2 = random.randint(0, height)
        draw.line([(x1, y1), (x2, y2)], fill=(random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)))
    
    # 绘制文字
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 30)
    except:
        font = ImageFont.load_default()
        
    for i, char in enumerate(code):
        draw.text((10 + i * 25, 10), char, font=font, fill=(random.randint(0, 150), random.randint(0, 150), random.randint(0, 150)))
    
    image = image.filter(ImageFilter.BLUR)
    return image, code
