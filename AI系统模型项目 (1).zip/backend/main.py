"""
AI System Model - FastAPI 后端主入口
包含：认证、验证码、文件管理、AI对话接口框架
"""
from fastapi import FastAPI, Depends, HTTPException, status, UploadFile, File, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse, FileResponse
from sqlalchemy.orm import Session
from typing import Optional
import os
import io
import logging
from datetime import timedelta

from models import SessionLocal, init_db, User, UploadedFile
from auth_utils import (
    get_password_hash, verify_password, create_access_token,
    ACCESS_TOKEN_EXPIRE_MINUTES, ALGORITHM, SECRET_KEY, truncate_password
)
from captcha import generate_captcha
from pydantic import BaseModel, EmailStr
import jwt

# 日志配置
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 初始化数据库
try:
    init_db()
    logger.info("数据库初始化成功")
except Exception as e:
    logger.error(f"数据库初始化失败: {e}")

app = FastAPI(title="AI System Model API", version="1.0.0")

# 跨域配置（开发/生产均放开）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# 允许的文件类型
ALLOWED_EXTENSIONS = {
    "txt", "pdf", "docx", "doc", "md",
    "jpg", "jpeg", "png", "gif", "webp", "svg",
    "py", "js", "ts", "jsx", "tsx", "vue", "html", "css", "json", "yaml", "yml",
    "zip", "tar", "gz", "rar",
    "csv", "xlsx", "xls"
}
MAX_FILE_SIZE = 20 * 1024 * 1024  # 20MB


def get_db():
    """数据库会话依赖"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


async def get_current_user(request: Request, db: Session = Depends(get_db)):
    """JWT Token 鉴权中间件"""
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="未提供有效的认证令牌",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = auth_header.split(" ")[1]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(status_code=401, detail="无效的令牌内容")
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="令牌已过期，请重新登录")
    except jwt.PyJWTError as e:
        logger.warning(f"Token解析失败: {e}")
        raise HTTPException(status_code=401, detail="令牌解析失败")

    try:
        user = db.query(User).filter(User.email == email).first()
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        return user
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"查询用户失败: {e}")
        raise HTTPException(status_code=500, detail="服务器内部错误")


# ==================== 数据模型 ====================

class RegisterRequest(BaseModel):
    email: str
    password: str

class LoginRequest(BaseModel):
    email: str
    password: str
    captcha_code: str

class AIRequest(BaseModel):
    prompt: str  # 统一使用 prompt 字段


# ==================== 认证接口 ====================

@app.post("/api/auth/register", summary="用户注册")
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    """用户注册（邮箱+密码，密码bcrypt加密）"""
    try:
        existing = db.query(User).filter(User.email == req.email).first()
        if existing:
            raise HTTPException(status_code=400, detail="该邮箱已被注册")

        hashed_pw = get_password_hash(truncate_password(req.password))
        user = User(email=req.email, hashed_password=hashed_pw)
        db.add(user)
        db.commit()
        db.refresh(user)
        logger.info(f"新用户注册成功: {req.email}")
        return {"msg": "注册成功", "user_id": user.id}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"注册失败: {e}")
        raise HTTPException(status_code=500, detail=f"数据库操作失败: {str(e)}")


@app.get("/api/auth/captcha", summary="获取图形验证码")
def get_captcha():
    """返回PNG格式图形验证码（实际验证逻辑已简化，生产建议配合session）"""
    try:
        image, code = generate_captcha()
        img_io = io.BytesIO()
        image.save(img_io, "PNG")
        img_io.seek(0)
        # 将验证码存入响应头（开发模式）
        response = StreamingResponse(img_io, media_type="image/png")
        response.headers["X-Captcha-Code"] = code
        return response
    except Exception as e:
        logger.error(f"验证码生成失败: {e}")
        raise HTTPException(status_code=500, detail="验证码生成失败")


@app.post("/api/auth/login", summary="用户登录")
def login(req: LoginRequest, db: Session = Depends(get_db)):
    """邮箱登录，返回JWT Token"""
    try:
        user = db.query(User).filter(User.email == req.email).first()
        if not user or not verify_password(req.password, user.hashed_password):
            raise HTTPException(status_code=401, detail="账号或密码错误")

        access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        access_token = create_access_token(
            data={"sub": user.email},
            expires_delta=access_token_expires
        )
        logger.info(f"用户登录成功: {req.email}")
        return {
            "access_token": access_token,
            "token_type": "bearer",
            "email": user.email
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"登录查询失败: {e}")
        raise HTTPException(status_code=500, detail=f"数据库操作失败: {str(e)}")


@app.get("/api/user/profile", summary="获取当前用户信息")
def get_profile(current_user: User = Depends(get_current_user)):
    return {"id": current_user.id, "email": current_user.email}


# ==================== 文件管理接口 ====================

@app.post("/api/files/upload", summary="上传文件")
def upload_file(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """上传文件（限制大小20MB，支持常见类型）"""
    if not file.filename:
        raise HTTPException(status_code=400, detail="未选择文件")

    # 检查文件扩展名
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"不支持的文件类型: .{ext}，允许类型: {', '.join(sorted(ALLOWED_EXTENSIONS))}"
        )

    try:
        file_content = file.file.read()
        if len(file_content) > MAX_FILE_SIZE:
            raise HTTPException(status_code=400, detail=f"文件大小超过 {MAX_FILE_SIZE // 1024 // 1024}MB 限制")

        # 生成唯一文件名防止覆盖
        import uuid
        unique_filename = f"{uuid.uuid4().hex}_{file.filename}"
        file_path = os.path.join(UPLOAD_DIR, unique_filename)

        with open(file_path, "wb") as buffer:
            buffer.write(file_content)

        db_file = UploadedFile(
            filename=unique_filename,
            original_name=file.filename,
            file_type=file.content_type or "application/octet-stream",
            size=len(file_content),
            owner_id=current_user.id
        )
        db.add(db_file)
        db.commit()
        db.refresh(db_file)

        logger.info(f"文件上传成功: {file.filename} by user {current_user.email}")
        return {
            "id": db_file.id,
            "name": db_file.original_name,
            "size": db_file.size,
            "type": db_file.file_type,
            "msg": "上传成功"
        }
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"文件上传失败: {e}")
        raise HTTPException(status_code=500, detail=f"文件上传失败: {str(e)}")


@app.get("/api/files/list", summary="获取文件列表")
def list_files(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """获取当前用户的文件列表"""
    try:
        files = db.query(UploadedFile).filter(
            UploadedFile.owner_id == current_user.id
        ).order_by(UploadedFile.id.desc()).all()

        return [
            {
                "id": f.id,
                "name": f.original_name,
                "size": f.size,
                "type": f.file_type,
                "upload_time": str(f.upload_time) if f.upload_time else ""
            }
            for f in files
        ]
    except Exception as e:
        logger.error(f"获取文件列表失败: {e}")
        raise HTTPException(status_code=500, detail=f"数据库操作失败: {str(e)}")


@app.delete("/api/files/{file_id}", summary="删除文件")
def delete_file(
    file_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """删除指定文件（仅限文件所有者）"""
    try:
        db_file = db.query(UploadedFile).filter(
            UploadedFile.id == file_id,
            UploadedFile.owner_id == current_user.id
        ).first()

        if not db_file:
            raise HTTPException(status_code=404, detail="文件不存在或无权限删除")

        # 删除磁盘文件
        file_path = os.path.join(UPLOAD_DIR, db_file.filename)
        if os.path.exists(file_path):
            os.remove(file_path)
            logger.info(f"磁盘文件已删除: {file_path}")

        db.delete(db_file)
        db.commit()
        return {"msg": "删除成功", "id": file_id}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"删除文件失败: {e}")
        raise HTTPException(status_code=500, detail=f"数据库操作失败: {str(e)}")


@app.get("/api/files/{file_id}/download", summary="下载文件")
def download_file(
    file_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """下载指定文件"""
    try:
        db_file = db.query(UploadedFile).filter(
            UploadedFile.id == file_id,
            UploadedFile.owner_id == current_user.id
        ).first()

        if not db_file:
            raise HTTPException(status_code=404, detail="文件不存在或无权限")

        file_path = os.path.join(UPLOAD_DIR, db_file.filename)
        if not os.path.exists(file_path):
            raise HTTPException(status_code=404, detail="文件已从磁盘丢失")

        return FileResponse(
            file_path,
            media_type=db_file.file_type,
            filename=db_file.original_name
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"下载文件失败: {e}")
        raise HTTPException(status_code=500, detail=f"文件下载失败: {str(e)}")


# ==================== AI 接口框架 ====================

@app.post("/api/ai/chat", summary="AI 对话接口（可扩展框架）")
def ai_chat(req: AIRequest, current_user: User = Depends(get_current_user)):
    """
    AI 对话接口框架
    - 当前为 Mock 响应，便于前后端联调
    - 替换此处逻辑即可接入 OpenAI / 本地 LLM 等真实模型
    """
    try:
        prompt = req.prompt.strip()
        if not prompt:
            raise HTTPException(status_code=400, detail="消息内容不能为空")

        # 🔌 接入真实 AI 模型时，替换此处逻辑即可
        # 示例：response = openai_client.chat.completions.create(...)
        mock_response = (
            f"[AI框架响应] 您好 {current_user.email.split('@')[0]}！"
            f"您发送了：「{prompt}」\n\n"
            "当前处于演示模式，此接口已预留完整的扩展框架。"
            "可替换此处为真实的 OpenAI / Claude / 本地模型调用。"
        )

        logger.info(f"AI对话请求来自: {current_user.email}")
        return {"response": mock_response, "model": "mock-v1"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"AI接口错误: {e}")
        raise HTTPException(status_code=500, detail=f"AI服务暂时不可用: {str(e)}")


@app.get("/api/health", summary="健康检查")
def health_check():
    return {"status": "ok", "service": "AI System Model API"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)