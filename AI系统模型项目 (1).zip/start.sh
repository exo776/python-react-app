#!/bin/bash
echo "正在启动 AI System Model..."

# 终止可能占用端口的旧进程
pkill -f "uvicorn" || true
pkill -f "vite" || true
pkill -f "node.*preview" || true
sleep 2

FRONTEND_PORT=${PORT:-3000}
BACKEND_PORT=8000

# 启动后端 (FastAPI) - 固定 8000 端口
echo "启动后端服务 (端口 $BACKEND_PORT)..."
cd backend
nohup python -m uvicorn main:app --host 0.0.0.0 --port $BACKEND_PORT > ../backend.log 2>&1 &
BACKEND_PID=$!
cd ..

# 等待后端启动
sleep 3

# 启动前端 (Vite 生产预览) - 使用环境变量端口
echo "启动前端服务 (端口 $FRONTEND_PORT)..."
cd frontend
nohup npx vite preview --host 0.0.0.0 --port $FRONTEND_PORT > ../frontend.log 2>&1 &
FRONTEND_PID=$!
cd ..

echo "系统已启动！"
echo "后端 PID: $BACKEND_PID (端口: $BACKEND_PORT)"
echo "前端 PID: $FRONTEND_PID (端口: $FRONTEND_PORT)"
echo "访问地址：http://localhost:$FRONTEND_PORT"
