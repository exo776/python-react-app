#!/bin/bash
echo "开始安装项目依赖..."

# 安装后端依赖
echo "正在安装 Python 后端依赖..."
cd backend
pip install -r requirements.txt -q
cd ..

# 安装前端依赖
echo "正在安装 Vue 前端依赖..."
cd frontend
npm install --silent
# 构建前端生产版本
echo "正在构建前端..."
npm run build --silent
cd ..

echo "✅ 依赖安装与构建完成！"
