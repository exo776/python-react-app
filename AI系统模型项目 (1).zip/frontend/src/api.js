import axios from 'axios'

// 创建 axios 实例，使用相对路径（通过 Vite proxy 转发至后端）
const api = axios.create({
  baseURL: '/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' }
})

// 请求拦截器：自动注入 Token
api.interceptors.request.use(
  config => {
    const token = localStorage.getItem('access_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  error => Promise.reject(error)
)

// 响应拦截器：统一错误处理
api.interceptors.response.use(
  response => response.data,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token')
      localStorage.removeItem('user_email')
      window.location.href = '/login'
    }
    return Promise.reject(error.response?.data || error.message)
  }
)

// ==================== 认证相关 ====================
export const authAPI = {
  /** 获取图形验证码（返回 blob 图片） */
  getCaptcha() {
    return api.get('/auth/captcha', { responseType: 'blob' })
  },

  /** 用户注册 */
  register(data) {
    return api.post('/auth/register', data)
  },

  /** 用户登录，返回 access_token */
  login(data) {
    return api.post('/auth/login', data)
  },

  /** 获取当前用户信息 */
  getProfile() {
    return api.get('/user/profile')
  }
}

// ==================== 文件相关 ====================
export const fileAPI = {
  /** 上传文件（multipart/form-data，自动携带 Token） */
  upload(file) {
    const formData = new FormData()
    formData.append('file', file)
    return api.post('/files/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    })
  },

  /** 获取文件列表 */
  list() {
    return api.get('/files/list')
  },

  /** 删除文件 */
  delete(fileId) {
    return api.delete(`/files/${fileId}`)
  },

  /** 下载文件（返回 Blob） */
  download(fileId) {
    return api.get(`/files/${fileId}/download`, {
      responseType: 'blob',
      // 下载时不走默认响应拦截器的 .data 提取，需要返回完整响应
      transformResponse: [(data) => data]
    })
  }
}

// ==================== AI 对话相关 ====================
export const aiAPI = {
  /** 发送 AI 消息，使用 prompt 字段（与后端一致） */
  chat(prompt) {
    return api.post('/ai/chat', { prompt })
  }
}

export default api
