<template>
  <div class="min-h-screen" style="background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);">
    <!-- 顶部导航 -->
    <nav class="backdrop-blur-sm border-b border-white/10" style="background: rgba(255,255,255,0.05);">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16 items-center">
          <div class="flex items-center space-x-3">
            <div class="w-8 h-8 rounded-lg flex items-center justify-center" style="background: linear-gradient(135deg, #667eea, #764ba2);">
              <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v10a2 2 0 01-2 2h-2" />
              </svg>
            </div>
            <span class="text-xl font-bold text-white tracking-tight">AI System Model</span>
          </div>
          <div class="flex items-center space-x-4">
            <span class="text-sm text-gray-300">{{ userEmail }}</span>
            <button @click="logout" class="px-4 py-1.5 text-sm text-white rounded-full border border-white/20 hover:bg-white/10 transition-all">
              退出登录
            </button>
          </div>
        </div>
      </div>
    </nav>

    <main class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
      <!-- Tab切换 -->
      <div class="flex space-x-2 mb-6">
        <button
          v-for="tab in tabs" :key="tab.id"
          @click="activeTab = tab.id"
          :class="['px-5 py-2 rounded-full text-sm font-medium transition-all duration-200',
            activeTab === tab.id
              ? 'text-white shadow-lg' : 'text-gray-400 hover:text-gray-200']"
          :style="activeTab === tab.id ? 'background: linear-gradient(135deg, #667eea, #764ba2);' : 'background: rgba(255,255,255,0.07);'"
        >
          {{ tab.label }}
        </button>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-5 gap-6">

        <!-- ========== 左侧主内容区 ========== -->
        <div class="lg:col-span-3 space-y-5">

          <!-- 文件管理 Tab -->
          <div v-show="activeTab === 'files'">
            <!-- 上传区 -->
            <div class="rounded-2xl p-6 border border-white/10" style="background: rgba(255,255,255,0.06);">
              <h3 class="text-white font-semibold mb-4 flex items-center space-x-2">
                <span class="w-6 h-6 rounded bg-purple-500/30 flex items-center justify-center text-purple-300 text-xs">📁</span>
                <span>文件上传</span>
              </h3>
              <div
                class="border-2 border-dashed border-white/20 rounded-xl p-8 text-center cursor-pointer hover:border-purple-400/60 transition-all"
                @click="$refs.fileInput.click()"
                @dragover.prevent
                @drop.prevent="handleDrop"
              >
                <div class="text-4xl mb-3">☁️</div>
                <p class="text-gray-300 text-sm">点击上传或拖拽文件到此处</p>
                <p class="text-gray-500 text-xs mt-1">支持 txt/pdf/docx/图片/代码/压缩包 · 最大 20MB</p>
                <input ref="fileInput" type="file" class="hidden" @change="handleFileUpload" :accept="acceptTypes">
              </div>
              <!-- 上传进度 -->
              <div v-if="uploading" class="mt-3">
                <div class="flex justify-between text-xs text-gray-400 mb-1">
                  <span>正在上传...</span><span>{{ uploadProgress }}%</span>
                </div>
                <div class="w-full bg-white/10 rounded-full h-1.5">
                  <div class="h-1.5 rounded-full transition-all" style="background: linear-gradient(90deg, #667eea, #764ba2);" :style="{width: uploadProgress + '%'}"></div>
                </div>
              </div>
              <!-- 操作消息 -->
              <div v-if="fileMsg" :class="['mt-3 text-xs px-3 py-2 rounded-lg', fileMsgType === 'success' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300']">
                {{ fileMsg }}
              </div>
            </div>

            <!-- 文件列表 -->
            <div class="mt-4 rounded-2xl p-6 border border-white/10" style="background: rgba(255,255,255,0.06);">
              <div class="flex justify-between items-center mb-4">
                <h3 class="text-white font-semibold">我的文件 <span class="text-gray-400 text-sm font-normal">({{ fileList.length }})</span></h3>
                <button @click="loadFileList" class="text-xs text-purple-400 hover:text-purple-300">刷新</button>
              </div>
              <div v-if="fileList.length === 0" class="text-center text-gray-500 py-8 text-sm">
                暂无文件，上传第一个文件吧 🚀
              </div>
              <div v-else class="space-y-2 max-h-72 overflow-y-auto pr-1">
                <div
                  v-for="file in fileList" :key="file.id"
                  class="flex items-center justify-between p-3 rounded-xl border border-white/5 hover:border-white/15 transition-all"
                  style="background: rgba(255,255,255,0.04);"
                >
                  <div class="flex items-center space-x-3 min-w-0">
                    <span class="text-xl flex-shrink-0">{{ getFileIcon(file.name) }}</span>
                    <div class="min-w-0">
                      <p class="text-white text-sm font-medium truncate" :title="file.name">{{ file.name }}</p>
                      <p class="text-gray-500 text-xs">{{ formatSize(file.size) }}</p>
                    </div>
                  </div>
                  <div class="flex items-center space-x-2 flex-shrink-0 ml-2">
                    <button @click="downloadFile(file)" class="p-1.5 text-blue-400 hover:text-blue-300 hover:bg-blue-500/10 rounded-lg transition-all" title="下载">
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                    </button>
                    <button @click="deleteFile(file.id)" class="p-1.5 text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg transition-all" title="删除">
                      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- 代码高亮 Tab -->
          <div v-show="activeTab === 'code'" class="rounded-2xl border border-white/10 overflow-hidden" style="background: rgba(255,255,255,0.06);">
            <div class="px-6 py-4 border-b border-white/10 flex items-center justify-between">
              <h3 class="text-white font-semibold">代码预览与高亮</h3>
              <div class="flex items-center space-x-3">
                <select v-model="codeLang" class="text-xs bg-white/10 text-gray-300 border border-white/10 rounded-lg px-2 py-1 focus:outline-none">
                  <option v-for="lang in languages" :key="lang.value" :value="lang.value">{{ lang.label }}</option>
                </select>
                <button @click="copyCode" class="text-xs px-3 py-1 rounded-full text-gray-300 border border-white/20 hover:bg-white/10 transition-all">
                  {{ copied ? '✅ 已复制' : '📋 复制' }}
                </button>
              </div>
            </div>
            <div class="p-4">
              <textarea
                v-model="codeSnippet"
                rows="8"
                class="w-full bg-transparent text-green-300 font-mono text-sm focus:outline-none resize-none placeholder-gray-600"
                placeholder="// 在此粘贴代码，下方将实时渲染..."
                spellcheck="false"
              ></textarea>
            </div>
            <div class="border-t border-white/10">
              <div class="px-4 py-2 flex items-center justify-between bg-black/30">
                <span class="text-xs text-gray-500 font-mono">预览 · {{ codeLang }}</span>
                <div class="flex space-x-1.5">
                  <div class="w-3 h-3 rounded-full bg-red-500/60"></div>
                  <div class="w-3 h-3 rounded-full bg-yellow-500/60"></div>
                  <div class="w-3 h-3 rounded-full bg-green-500/60"></div>
                </div>
              </div>
              <div class="p-4 bg-black/40 overflow-x-auto">
                <pre class="text-sm leading-relaxed"><code :class="`language-${codeLang} hljs`" v-html="highlightedCode"></code></pre>
              </div>
            </div>
          </div>

        </div>

        <!-- ========== 右侧 AI 对话 ========== -->
        <div class="lg:col-span-2 rounded-2xl border border-white/10 flex flex-col" style="background: rgba(255,255,255,0.06); height: 600px;">
          <!-- 标题 -->
          <div class="px-5 py-4 border-b border-white/10 flex items-center space-x-3">
            <div class="w-8 h-8 rounded-full flex items-center justify-center" style="background: linear-gradient(135deg, #667eea, #764ba2);">
              <span class="text-sm">🤖</span>
            </div>
            <div>
              <h3 class="text-white font-semibold text-sm">AI 助手</h3>
              <p class="text-green-400 text-xs">● 在线</p>
            </div>
          </div>

          <!-- 消息区 -->
          <div class="flex-1 p-4 overflow-y-auto space-y-3" ref="chatContainer">
            <div v-for="(msg, idx) in chatHistory" :key="idx" :class="['flex', msg.role === 'user' ? 'justify-end' : 'justify-start']">
              <div
                :class="['max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed', msg.role === 'user' ? 'rounded-tr-sm text-white' : 'rounded-tl-sm text-gray-200']"
                :style="msg.role === 'user' ? 'background: linear-gradient(135deg, #667eea, #764ba2);' : 'background: rgba(255,255,255,0.1);'"
              >
                {{ msg.content }}
              </div>
            </div>
            <!-- AI 正在输入 -->
            <div v-if="aiLoading" class="flex justify-start">
              <div class="rounded-2xl rounded-tl-sm px-4 py-2.5 text-sm" style="background: rgba(255,255,255,0.1);">
                <span class="flex space-x-1">
                  <span class="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce" style="animation-delay:0s"></span>
                  <span class="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce" style="animation-delay:0.15s"></span>
                  <span class="w-1.5 h-1.5 rounded-full bg-gray-400 animate-bounce" style="animation-delay:0.3s"></span>
                </span>
              </div>
            </div>
          </div>

          <!-- 输入区 -->
          <div class="p-4 border-t border-white/10">
            <div class="flex space-x-2">
              <input
                v-model="aiInput"
                @keyup.enter="sendAiMessage"
                type="text"
                class="flex-1 px-4 py-2 rounded-full text-sm text-white placeholder-gray-500 focus:outline-none border border-white/10 focus:border-purple-400/50 transition-all"
                style="background: rgba(255,255,255,0.07);"
                placeholder="输入消息，按 Enter 发送..."
              >
              <button
                @click="sendAiMessage"
                :disabled="aiLoading"
                class="w-9 h-9 rounded-full flex items-center justify-center text-white flex-shrink-0 transition-all disabled:opacity-50"
                style="background: linear-gradient(135deg, #667eea, #764ba2);"
              >
                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              </button>
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, computed } from 'vue'
import { useRouter } from 'vue-router'
import { fileAPI, aiAPI } from '../api.js'

const router = useRouter()

// ---- 用户信息 ----
const userEmail = ref(localStorage.getItem('user_email') || '用户')

// ---- Tab ----
const activeTab = ref('files')
const tabs = [
  { id: 'files', label: '📁 文件管理' },
  { id: 'code',  label: '💻 代码高亮' },
]

// ---- 文件管理 ----
const fileInput = ref(null)
const fileList = ref([])
const uploading = ref(false)
const uploadProgress = ref(0)
const fileMsg = ref('')
const fileMsgType = ref('success')

const acceptTypes = '.txt,.pdf,.docx,.doc,.md,.jpg,.jpeg,.png,.gif,.webp,.svg,.py,.js,.ts,.jsx,.tsx,.vue,.html,.css,.json,.yaml,.yml,.zip,.tar,.gz,.rar,.csv,.xlsx,.xls'

function showFileMsg(msg, type = 'success') {
  fileMsg.value = msg
  fileMsgType.value = type
  setTimeout(() => { fileMsg.value = '' }, 3000)
}

function getFileIcon(name) {
  const ext = name.split('.').pop()?.toLowerCase()
  const icons = {
    pdf: '📄', docx: '📝', doc: '📝', txt: '📃', md: '📋',
    jpg: '🖼️', jpeg: '🖼️', png: '🖼️', gif: '🎞️', svg: '🎨', webp: '🖼️',
    py: '🐍', js: '🟨', ts: '🔷', vue: '💚', html: '🌐', css: '🎨',
    json: '📦', zip: '🗜️', rar: '🗜️', gz: '🗜️', tar: '🗜️',
    csv: '📊', xlsx: '📊', xls: '📊',
  }
  return icons[ext] || '📎'
}

function formatSize(bytes) {
  if (!bytes) return '0 B'
  if (bytes < 1024) return bytes + ' B'
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
  return (bytes / 1024 / 1024).toFixed(2) + ' MB'
}

async function loadFileList() {
  try {
    fileList.value = await fileAPI.list()
  } catch (e) {
    console.error('加载文件列表失败', e)
  }
}

async function handleFileUpload(event) {
  const file = event.target.files[0]
  if (!file) return
  await doUpload(file)
  event.target.value = ''
}

function handleDrop(event) {
  const file = event.dataTransfer.files[0]
  if (file) doUpload(file)
}

async function doUpload(file) {
  uploading.value = true
  uploadProgress.value = 10
  const timer = setInterval(() => {
    if (uploadProgress.value < 80) uploadProgress.value += 15
  }, 200)
  try {
    await fileAPI.upload(file)
    uploadProgress.value = 100
    showFileMsg(`✅ "${file.name}" 上传成功！`, 'success')
    await loadFileList()
  } catch (e) {
    const msg = typeof e === 'string' ? e : (e?.detail || e?.message || '上传失败')
    showFileMsg(`❌ ${msg}`, 'error')
  } finally {
    clearInterval(timer)
    setTimeout(() => { uploading.value = false; uploadProgress.value = 0 }, 500)
  }
}

async function deleteFile(fileId) {
  if (!confirm('确定删除此文件？')) return
  try {
    await fileAPI.delete(fileId)
    showFileMsg('🗑️ 文件已删除', 'success')
    await loadFileList()
  } catch (e) {
    showFileMsg('❌ 删除失败', 'error')
  }
}

async function downloadFile(file) {
  try {
    const blob = await fileAPI.download(file.id)
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = file.name
    a.click()
    URL.revokeObjectURL(url)
  } catch (e) {
    alert('下载失败')
  }
}

// ---- 代码高亮 ----
const codeSnippet = ref(`// 欢迎使用 AI System Model 代码预览
function greet(name) {
  const message = \`Hello, \${name}! 🚀\`
  console.log(message)
  return message
}

greet('AI System')`)
const codeLang = ref('javascript')
const copied = ref(false)
const languages = [
  { value: 'javascript', label: 'JavaScript' },
  { value: 'python', label: 'Python' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'html', label: 'HTML' },
  { value: 'css', label: 'CSS' },
  { value: 'json', label: 'JSON' },
  { value: 'bash', label: 'Bash' },
  { value: 'sql', label: 'SQL' },
]

// 简易语法高亮（无需依赖库）
const highlightedCode = computed(() => {
  let code = codeSnippet.value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')

  if (['javascript', 'typescript'].includes(codeLang.value)) {
    code = code
      .replace(/(\/\/.*)/g, '<span style="color:#6a9955">$1</span>')
      .replace(/\b(const|let|var|function|return|if|else|for|while|class|import|export|from|async|await|new|typeof|this|=>)\b/g, '<span style="color:#c792ea">$1</span>')
      .replace(/(&quot;[^&]*&quot;|&#39;[^&]*&#39;|`[^`]*`)/g, '<span style="color:#a8ff78">$1</span>')
      .replace(/\b(\d+)\b/g, '<span style="color:#f78c6c">$1</span>')
  } else if (codeLang.value === 'python') {
    code = code
      .replace(/(#.*)/g, '<span style="color:#6a9955">$1</span>')
      .replace(/\b(def|class|import|from|return|if|elif|else|for|while|in|not|and|or|True|False|None|print|self|with|as|try|except|raise|lambda)\b/g, '<span style="color:#c792ea">$1</span>')
      .replace(/(&quot;[^&]*&quot;|&#39;[^&]*&#39;)/g, '<span style="color:#a8ff78">$1</span>')
  } else if (codeLang.value === 'html') {
    code = code
      .replace(/(&lt;\/?[a-zA-Z][^&gt;]*&gt;)/g, '<span style="color:#80cbc4">$1</span>')
      .replace(/(class|id|href|src|style)=/g, '<span style="color:#c792ea">$1</span>=')
  }
  return code
})

async function copyCode() {
  try {
    await navigator.clipboard.writeText(codeSnippet.value)
    copied.value = true
    setTimeout(() => { copied.value = false }, 2000)
  } catch { alert('复制失败') }
}

// ---- AI 对话 ----
const chatContainer = ref(null)
const aiInput = ref('')
const aiLoading = ref(false)
const chatHistory = ref([
  { role: 'assistant', content: '你好！我是你的 AI 助手 🤖 有什么可以帮你的吗？可以问我任何问题！' }
])

async function sendAiMessage() {
  const msg = aiInput.value.trim()
  if (!msg || aiLoading.value) return

  chatHistory.value.push({ role: 'user', content: msg })
  aiInput.value = ''
  aiLoading.value = true

  await nextTick()
  if (chatContainer.value) {
    chatContainer.value.scrollTop = chatContainer.value.scrollHeight
  }

  try {
    const res = await aiAPI.chat(msg)
    chatHistory.value.push({ role: 'assistant', content: res.response })
  } catch (e) {
    const errMsg = typeof e === 'string' ? e : (e?.detail || '服务暂时不可用，请稍后重试。')
    chatHistory.value.push({ role: 'assistant', content: `⚠️ ${errMsg}` })
  } finally {
    aiLoading.value = false
    await nextTick()
    if (chatContainer.value) {
      chatContainer.value.scrollTop = chatContainer.value.scrollHeight
    }
  }
}

function logout() {
  localStorage.removeItem('access_token')
  localStorage.removeItem('user_email')
  router.push('/login')
}

onMounted(() => {
  loadFileList()
})
</script>
