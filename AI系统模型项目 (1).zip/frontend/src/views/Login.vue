<template>
  <div class="min-h-screen flex items-center justify-center" style="background: linear-gradient(135deg, #0f0c29, #302b63, #24243e);">
    <!-- 背景装饰 -->
    <div class="absolute inset-0 overflow-hidden pointer-events-none">
      <div class="absolute -top-32 -left-32 w-96 h-96 rounded-full opacity-20" style="background: radial-gradient(circle, #667eea, transparent);"></div>
      <div class="absolute -bottom-32 -right-32 w-96 h-96 rounded-full opacity-20" style="background: radial-gradient(circle, #764ba2, transparent);"></div>
    </div>

    <div class="relative z-10 w-full max-w-md px-4">
      <!-- Logo -->
      <div class="text-center mb-8">
        <div class="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center" style="background: linear-gradient(135deg, #667eea, #764ba2);">
          <svg class="w-9 h-9 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v10a2 2 0 01-2 2h-2" />
          </svg>
        </div>
        <h1 class="text-3xl font-bold text-white tracking-tight">AI System Model</h1>
        <p class="text-gray-400 text-sm mt-1">智能 · 安全 · 可扩展</p>
      </div>

      <!-- 卡片 -->
      <div class="rounded-3xl p-8 border border-white/10" style="background: rgba(255,255,255,0.07); backdrop-filter: blur(20px);">
        <!-- Tab 切换：登录 / 注册 -->
        <div class="flex rounded-xl p-1 mb-6" style="background: rgba(0,0,0,0.3);">
          <button
            @click="mode = 'login'"
            :class="['flex-1 py-2 text-sm font-medium rounded-lg transition-all', mode === 'login' ? 'text-white shadow' : 'text-gray-400 hover:text-gray-200']"
            :style="mode === 'login' ? 'background: linear-gradient(135deg, #667eea, #764ba2);' : ''"
          >登录</button>
          <button
            @click="mode = 'register'"
            :class="['flex-1 py-2 text-sm font-medium rounded-lg transition-all', mode === 'register' ? 'text-white shadow' : 'text-gray-400 hover:text-gray-200']"
            :style="mode === 'register' ? 'background: linear-gradient(135deg, #667eea, #764ba2);' : ''"
          >注册</button>
        </div>

        <form @submit.prevent="mode === 'login' ? handleLogin() : handleRegister()" class="space-y-4">
          <!-- 邮箱 -->
          <div>
            <label class="block text-xs font-medium text-gray-400 mb-1.5 ml-1">邮箱地址</label>
            <div class="relative">
              <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
              </span>
              <input
                v-model="email" type="email" required autocomplete="email"
                class="w-full pl-10 pr-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 border border-white/10 focus:border-purple-400/60 focus:outline-none transition-all"
                style="background: rgba(255,255,255,0.06);"
                placeholder="your@email.com"
              >
            </div>
          </div>

          <!-- 密码 -->
          <div>
            <label class="block text-xs font-medium text-gray-400 mb-1.5 ml-1">密码</label>
            <div class="relative">
              <span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-500">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
              </span>
              <input
                v-model="password" :type="showPwd ? 'text' : 'password'" required
                class="w-full pl-10 pr-10 py-3 rounded-xl text-sm text-white placeholder-gray-600 border border-white/10 focus:border-purple-400/60 focus:outline-none transition-all"
                style="background: rgba(255,255,255,0.06);"
                placeholder="••••••••"
              >
              <button type="button" @click="showPwd = !showPwd" class="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-300">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path v-if="!showPwd" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                  <path v-else stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21"/>
                </svg>
              </button>
            </div>
          </div>

          <!-- 验证码（仅登录时显示）-->
          <div v-if="mode === 'login'">
            <label class="block text-xs font-medium text-gray-400 mb-1.5 ml-1">图形验证码</label>
            <div class="flex space-x-3">
              <input
                v-model="captchaCode" type="text" required maxlength="4"
                class="flex-1 px-4 py-3 rounded-xl text-sm text-white placeholder-gray-600 border border-white/10 focus:border-purple-400/60 focus:outline-none tracking-widest uppercase transition-all"
                style="background: rgba(255,255,255,0.06);"
                placeholder="XXXX"
              >
              <div class="relative cursor-pointer flex-shrink-0" @click="refreshCaptcha" title="点击刷新验证码">
                <img
                  :src="captchaUrl"
                  class="h-12 rounded-xl border border-white/10 object-cover"
                  style="width: 120px; background: #fff;"
                  alt="验证码"
                  @error="captchaError = true"
                >
                <div class="absolute inset-0 flex items-center justify-center rounded-xl opacity-0 hover:opacity-100 transition-opacity" style="background: rgba(0,0,0,0.4);">
                  <span class="text-white text-xs">刷新</span>
                </div>
              </div>
            </div>
          </div>

          <!-- 错误/成功提示 -->
          <div v-if="alertMsg" :class="['px-4 py-3 rounded-xl text-sm border', alertType === 'error' ? 'bg-red-500/10 text-red-300 border-red-500/20' : 'bg-green-500/10 text-green-300 border-green-500/20']">
            {{ alertMsg }}
          </div>

          <!-- 提交按钮 -->
          <button
            type="submit"
            :disabled="loading"
            class="w-full py-3 rounded-xl font-semibold text-white text-sm transition-all disabled:opacity-60 disabled:cursor-not-allowed hover:opacity-90 active:scale-[0.98]"
            style="background: linear-gradient(135deg, #667eea, #764ba2); box-shadow: 0 4px 20px rgba(102,126,234,0.4);"
          >
            <span v-if="loading" class="flex items-center justify-center space-x-2">
              <svg class="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"></path>
              </svg>
              <span>{{ mode === 'login' ? '登录中...' : '注册中...' }}</span>
            </span>
            <span v-else>{{ mode === 'login' ? '立即登录 →' : '创建账号 →' }}</span>
          </button>
        </form>
      </div>

      <p class="text-center text-gray-600 text-xs mt-6">
        © 2025 AI System Model · 基于 Vue 3 + FastAPI 构建
      </p>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { authAPI } from '../api.js'

const router = useRouter()

const mode = ref('login')         // 'login' | 'register'
const email = ref('')
const password = ref('')
const captchaCode = ref('')
const captchaUrl = ref('')
const showPwd = ref(false)
const loading = ref(false)
const alertMsg = ref('')
const alertType = ref('error')
const captchaError = ref(false)

function showAlert(msg, type = 'error') {
  alertMsg.value = msg
  alertType.value = type
  setTimeout(() => { alertMsg.value = '' }, 4000)
}

function refreshCaptcha() {
  captchaError.value = false
  captchaUrl.value = `/api/auth/captcha?t=${Date.now()}`
}

async function handleLogin() {
  if (!email.value || !password.value || !captchaCode.value) {
    showAlert('请填写所有字段')
    return
  }
  loading.value = true
  try {
    const res = await authAPI.login({
      email: email.value,
      password: password.value,
      captcha_code: captchaCode.value,
    })
    localStorage.setItem('access_token', res.access_token)
    localStorage.setItem('user_email', res.email || email.value)
    showAlert('登录成功，正在跳转...', 'success')
    setTimeout(() => router.push('/dashboard'), 800)
  } catch (e) {
    const msg = typeof e === 'string' ? e : (e?.detail || '登录失败，请检查账号密码')
    showAlert(msg)
    refreshCaptcha()
  } finally {
    loading.value = false
  }
}

async function handleRegister() {
  if (!email.value || !password.value) {
    showAlert('请填写邮箱和密码')
    return
  }
  if (password.value.length < 6) {
    showAlert('密码长度至少 6 位')
    return
  }
  loading.value = true
  try {
    await authAPI.register({ email: email.value, password: password.value })
    showAlert('注册成功！请登录', 'success')
    mode.value = 'login'
    password.value = ''
    captchaCode.value = ''
    refreshCaptcha()
  } catch (e) {
    const msg = typeof e === 'string' ? e : (e?.detail || '注册失败')
    showAlert(msg)
  } finally {
    loading.value = false
  }
}

onMounted(refreshCaptcha)
</script>
