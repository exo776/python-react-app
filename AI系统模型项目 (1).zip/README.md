# AI System Model 项目

一个完整的全栈AI系统模型项目，包含用户认证、文件管理、代码高亮展示和可扩展的AI对话接口。

## 技术栈

### 前端
- **Vue 3** - 渐进式JavaScript框架
- **Vite** - 快速的前端构建工具
- **TailwindCSS** - 实用优先的CSS框架
- **Vue Router** - 官方路由管理器
- **Axios** - HTTP客户端
- **Highlight.js** - 代码语法高亮库

### 后端
- **FastAPI** - 高性能Python Web框架
- **SQLite** - 轻量级嵌入式数据库
- **JWT** - JSON Web Token认证
- **Passlib** - 密码加密处理
- **Pillow** - 图像处理（验证码生成）

## 功能特性

### 1. 用户认证系统
- ✅ 邮箱注册/登录
- ✅ 图形验证码（防机器人）
- ✅ BCrypt密码加密存储
- ✅ JWT Token鉴权
- ✅ 登录状态持久化（7天有效期）

### 2. 文件上传模块
- ✅ 支持多种文件格式（文档、图片、代码、压缩包等）
- ✅ 文件大小限制（10MB）
- ✅ 文件类型白名单验证
- ✅ 文件列表展示
- ✅ 文件下载功能
- ✅ 文件删除功能
- ✅ 拖拽上传支持

### 3. 代码高亮展示
- ✅ 支持8种编程语言（JavaScript, Python, Java, C++, HTML, CSS, JSON, SQL）
- ✅ 行号显示
- ✅ 一键复制代码
- ✅ Atom One Dark深色主题
- ✅ 实时渲染预览

### 4. AI对话框架
- ✅ 可扩展的AI接口设计
- ✅ 对话历史记录
- ✅ 实时消息发送/接收
- ✅ Mock响应（可替换为真实AI API）
- ✅ 自动滚动到底部

## 项目结构

```
ai_system_model_project_7443/
├── backend/                 # 后端目录
│   ├── main.py             # FastAPI主应用
│   ├── database.py         # 数据库初始化
│   ├── auth_utils.py       # 认证工具（JWT、密码加密）
│   ├── captcha.py          # 验证码生成
│   ├── requirements.txt    # Python依赖
│   └── uploads/            # 上传文件存储目录
├── frontend/               # 前端目录
│   ├── src/
│   │   ├── views/
│   │   │   ├── LoginView.vue      # 登录页面
│   │   │   ├── RegisterView.vue   # 注册页面
│   │   │   └── DashboardView.vue  # 主仪表板
│   │   ├── components/     # 组件目录
│   │   ├── api.js          # API服务封装
│   │   ├── router.js       # 路由配置
│   │   ├── App.vue         # 根组件
│   │   ├── main.js         # 入口文件
│   │   └── style.css       # 全局样式
│   ├── index.html          # HTML模板
│   ├── vite.config.js      # Vite配置
│   ├── tailwind.config.js  # Tailwind配置
│   ├── postcss.config.js   # PostCSS配置
│   └── package.json        # Node依赖
├── install.sh              # 安装脚本
├── start.sh                # 启动脚本
└── README.md               # 项目说明
```

## 快速开始

### 前置要求
- Python 3.8+
- Node.js 16+
- npm 或 yarn

### 方式一：使用安装脚本（推荐）

```bash
# 赋予执行权限
chmod +x install.sh start.sh

# 运行安装脚本
./install.sh

# 启动项目
./start.sh
```

### 方式二：手动安装

#### 1. 安装后端依赖

```bash
cd backend
pip install -r requirements.txt
```

#### 2. 安装前端依赖

```bash
cd frontend
npm install
```

#### 3. 启动后端服务

```bash
cd backend
python main.py
```

后端服务将运行在 `http://localhost:8000`

#### 4. 启动前端开发服务器

```bash
cd frontend
npm run dev
```

前端应用将运行在 `http://localhost:3000`

## API接口文档

### 认证接口

#### 获取验证码
```
GET /api/captcha/generate
Response: { "captcha_id": "uuid", "image": "base64图片" }
```

#### 用户注册
```
POST /api/auth/register
Body: { "email": "user@example.com", "password": "password", "captcha_code": "ABCD", "captcha_id": "uuid" }
```

#### 用户登录
```
POST /api/auth/login
Body: { "email": "user@example.com", "password": "password", "captcha_code": "ABCD", "captcha_id": "uuid" }
Response: { "access_token": "jwt_token", "token_type": "bearer" }
```

#### 获取用户信息
```
GET /api/user/profile
Headers: Authorization: Bearer <token>
```

### 文件接口

#### 上传文件
```
POST /api/files/upload
Headers: Authorization: Bearer <token>
Content-Type: multipart/form-data
Body: file=<file>
```

#### 获取文件列表
```
GET /api/files/list
Headers: Authorization: Bearer <token>
```

#### 删除文件
```
DELETE /api/files/{file_id}
Headers: Authorization: Bearer <token>
```

#### 下载文件
```
GET /api/files/{file_id}/download
Headers: Authorization: Bearer <token>
```

### AI对话接口

#### 发送消息
```
POST /api/ai/chat
Headers: Authorization: Bearer <token>
Body: { "content": "你好" }
Response: { "response": "AI回复内容", "model": "mock-model" }
```

#### 获取对话历史
```
GET /api/ai/history
Headers: Authorization: Bearer <token>
```

## 接入真实AI模型

项目中AI接口使用Mock实现，您可以轻松替换为真实的AI模型API。

### 示例：接入OpenAI GPT

修改 `backend/main.py` 中的 `ai_chat` 函数：

```python
import openai

openai.api_key = "your-api-key"

@app.post("/api/ai/chat")
async def ai_chat(message: ChatMessage, current_user: dict = Depends(get_current_user)):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "你是一个有用的AI助手"},
                {"role": "user", "content": message.content}
            ]
        )
        ai_response = response.choices[0].message.content
        
        # 保存到数据库...
        
        return AIResponse(response=ai_response, model="gpt-3.5-turbo")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### 其他支持的AI模型
- Anthropic Claude
- Google Gemini
- 本地部署的LLaMA、ChatGLM等
- 阿里云通义千问
- 百度文心一言

## 生产部署

### 后端部署

#### 使用Gunicorn + Uvicorn

```bash
pip install gunicorn
gunicorn backend.main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

#### 使用Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY backend/requirements.txt .
RUN pip install -r requirements.txt

COPY backend/ .
RUN mkdir -p uploads

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 前端部署

#### 构建静态文件

```bash
cd frontend
npm run build
```

生成的文件在 `frontend/dist` 目录，可以部署到：
- Nginx
- Apache
- Vercel
- Netlify
- Cloudflare Pages

#### Nginx配置示例

```nginx
server {
    listen 80;
    server_name your-domain.com;

    root /path/to/frontend/dist;
    index index.html;

    location / {
        try_files $uri $uri/ /index.html;
    }

    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## 安全建议

1. **修改SECRET_KEY**：在生产环境中修改 `backend/auth_utils.py` 中的 `SECRET_KEY`
2. **启用HTTPS**：使用SSL证书加密通信
3. **设置CORS白名单**：修改 `backend/main.py` 中的 `allow_origins`
4. **文件上传限制**：根据实际需求调整文件大小和类型限制
5. **数据库备份**：定期备份 `backend/app.db` 文件
6. **环境变量**：敏感信息使用环境变量管理

## 常见问题

### 1. 端口被占用
修改 `backend/main.py` 中的端口号或 `frontend/vite.config.js` 中的端口配置

### 2. 数据库文件不存在
首次运行时会自动创建数据库，如果出错请删除 `backend/app.db` 后重新启动

### 3. 验证码不显示
确保已安装Pillow库：`pip install pillow`

### 4. 前端跨域问题
开发环境下Vite已配置代理，生产环境需要配置Nginx反向代理

## 许可证

MIT License

## 联系方式

如有问题或建议，欢迎提交Issue。
